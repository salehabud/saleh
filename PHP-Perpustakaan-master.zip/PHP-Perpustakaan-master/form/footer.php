<div class="container">

        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; 2016 - <?php echo date("Y"); ?> by Yudha Tri Putra </p>
					<p>web ini hanya sample saja.</p>
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->
	<script src="../template/js/jquery-3.1.1.min.js"></script>
	<script src="../template/js/jquery-ui-1.11.4/jquery-ui.js"></script>
	<script src="../template/js/sb-admin-2.js"></script>
	<script src="../template/js/bootstrap.min.js"></script>
</body>
</html>
