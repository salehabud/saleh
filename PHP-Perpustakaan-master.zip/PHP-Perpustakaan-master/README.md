# PHP-Perpustakaan
Aplikasi Perpustakaan sederhana berbasis Web

Dibuat dengan:
- PHP 7.0 Native
- MySQL (MySQLi)
- JQuery
- Bootstrap 3
- TCPDF

Fitur:
- Peminjaman,Pengembalian
- Add buku, staff
- Filter data buku, katalog buku
- History Peminjaman
- Report
- etc

User Test:
user	: ytp
password: ytp1234

user	: adm
password: adm1234